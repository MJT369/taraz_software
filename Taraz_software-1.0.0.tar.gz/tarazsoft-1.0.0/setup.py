from setuptools import setup, find_packages

setup(
    name='TarazSoft',
    version='1.0.0',
    packages=find_packages(),
    py_modules=['taraz'],
    install_requires=[
    'PyQt5==5.15.11',
    'ttkthemes',
    'langdetect==1.0.9',
    'pdf2docx==0.5.8',
   'python-docx==0.8.11',
    'spellchecker==0.4',
    'translatepy==2.3',
    'argostranslate==1.9.6',
    'googletrans==4.0.0rc1',
    'deep_translator==1.11.4',
    'wikipedia==1.4.0',
    'farsi_tools==0.1.0',
    'autocorrect==2.5.0',
    'requests==2.25.1',
    'urllib3==1.26.5',
    'ftfy==6.0.3',
    'camelot==12.6.29',
    'pandas==1.5.3',
    'pypdf==3.8.1',
    'openpyxl==3.1.2',
    'pyperclip==1.8.2',

    ],
    entry_points={
        'console_scripts': [
            'taraz=taraz:main',  # Replace 'main' with the function you want to run
        ],
    },
)
