from setuptools import setup, find_packages

setup(
    name='TarazSoft',
    version='1.0.0',
    packages=find_packages(),
    py_modules=['taraz'],
    install_requires=[
        'PyQt5',
        'ttkthemes',
        'bidi',
        'langdetect',
        'pdf2docx',
        'docx',
        'spellchecker',
        'translatepy',
        'argostranslate',
        'googletrans',
        'deep_translator',
        'translators',
        'google_searching',
        'wikipedia',
        'gc',
        'shutil',
        'farsi_tools',
        'autocorrect',
        'requests',
        'urllib3',
        'hashlib',
        'unicodedata',
        'ftfy',
        'camelot',
        'pandas',
        'pypdf',
        'openpyxl',
        'pyperclip',
        'ttkthemes',
    ],
    entry_points={
        'console_scripts': [
            'taraz=taraz:main',  # Replace 'main' with the function you want to run
        ],
    },
)
